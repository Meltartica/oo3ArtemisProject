import acm.graphics.*;
import acm.program.*;

public class MainMenu extends ConsoleProgram {

    private GCanvas canvas;

    public void run() {
        int choice;

        do {
            println("--- RIPPLE EFFECT ---");
            println(" (1)  Start Game     ");
            println(" (2)  View Scores    ");
            println(" (3)  Exit Game      ");
            choice = readInt("Choice: ");

            switch (choice) {
                case 1:
                    canvas.clear();
                    // Start Game
                    break;
                case 2:
                    // View Scores
                    break;
                case 3:
                    println("Thank you for playing Ripple Effect.");
                    pause(2500);
                    exit();
                default:
                    println("Invalid input.");
                    break;
            }

        } while ( choice != 3 );
    }

    public void init() {
        canvas = new GCanvas();
        setTitle("Ripple Effect");
        setSize(1080, 540);
        add(canvas);
    }

    public static void main(String[] args) { (new MainMenu()).start(args); }
}