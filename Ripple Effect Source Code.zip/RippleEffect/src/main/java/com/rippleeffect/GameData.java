/*
Classname: GameData.java
Author: Win Sy, Leigh Tabanao, Timothy Tiu
Date: July 24, 2023
Description: Abstract Class for Game Data with Setter and Getter Methods
*/

package com.rippleeffect;

import java.io.Serializable;

/**
 * The GameData class represents the data of a player's game session in the Ripple Effect game.
 * It implements the Serializable interface to allow objects of this class to be serialized and
 * deserialized, enabling easy saving and loading of game data.
 */
public class GameData implements Serializable {

    private String name; // Player's name
    private int score; // Player's score
    private int correctAnswers; // Number of correct answers given by the player
    private int wrongAnswers; // Number of wrong answers given by the player

    /**
     * Constructs a GameData object with the provided player data.
     *
     * @param name           The name of the player.
     * @param score          The player's score.
     * @param correctAnswers The number of correct answers given by the player.
     * @param wrongAnswers   The number of wrong answers given by the player.
     */
    public GameData(String name, int score, int correctAnswers, int wrongAnswers) {
        this.name = name;
        this.score = score;
        this.correctAnswers = correctAnswers;
        this.wrongAnswers = wrongAnswers;
    }

    /**
     * Gets the name of the player.
     *
     * @return The player's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the player.
     *
     * @param name The player's name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the player's score.
     *
     * @return The player's score.
     */
    public int getScore() {
        return score;
    }

    /**
     * Sets the player's score.
     *
     * @param score The player's score.
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Gets the number of correct answers given by the player.
     *
     * @return The number of correct answers.
     */
    public int getCorrectAnswers() {
        return correctAnswers;
    }

    /**
     * Sets the number of correct answers given by the player.
     *
     * @param correctAnswers The number of correct answers.
     */
    public void setCorrectAnswers(int correctAnswers) {
        this.correctAnswers = correctAnswers;
    }

    /**
     * Gets the number of wrong answers given by the player.
     *
     * @return The number of wrong answers.
     */
    public int getWrongAnswers() {
        return wrongAnswers;
    }

    /**
     * Sets the number of wrong answers given by the player.
     *
     * @param wrongAnswers The number of wrong answers.
     */
    public void setWrongAnswers(int wrongAnswers) {
        this.wrongAnswers = wrongAnswers;
    }
}
