/*
Classname: PreviousData.java
Author: Win Sy, Leigh Tabanao, Timothy Tiu
Date: July 25, 2023
Description: Abstract Class for Previous Game Data with Setter and Getter Methods
*/

package com.rippleeffect;

import java.io.Serializable;

/**
 * The PreviousData class represents the data of a player's previous game session in the Ripple Effect game.
 * It implements the Serializable interface to allow objects of this class to be serialized and
 * deserialized, enabling easy saving and loading of game data.
 */
public class PreviousData implements Serializable {

    private int previous_score; // Player's score
    private int previous_correctAnswers; // Number of correct answers given by the player
    private int previous_wrongAnswers; // Number of wrong answers given by the player

    /**
     * Constructs a GameData object with the provided player data.
     *
     * @param previous_score          The player's previous score.
     * @param previous_correctAnswers The previous number of correct answers given by the player.
     * @param previous_wrongAnswers   The previous number of wrong answers given by the player.
     */
    public PreviousData(int previous_score, int previous_correctAnswers, int previous_wrongAnswers) {
        this.previous_score = previous_score;
        this.previous_correctAnswers = previous_correctAnswers;
        this.previous_wrongAnswers = previous_wrongAnswers;
    }

    /**
     * Gets the player's previous score.
     *
     * @return The player's previous score.
     */
    public int getPreviousScore() {
        return previous_score;
    }

    /**
     * Sets the player's previous score.
     *
     * @param score The player's previous score.
     */
    public void setPreviousScore(int score) {
        this.previous_score = score;
    }

    /**
     * Gets the previous number of correct answers given by the player.
     *
     * @return The previous number of correct answers.
     */
    public int getPreviousCorrectAnswers() {
        return previous_correctAnswers;
    }

    /**
     * Sets the previous number of correct answers given by the player.
     *
     * @param correctAnswers The number of correct answers.
     */
    public void setPreviousCorrectAnswers(int correctAnswers) {
        this.previous_correctAnswers = correctAnswers;
    }

    /**
     * Gets the previous number of wrong answers given by the player.
     *
     * @return The number of wrong answers.
     */
    public int getPreviousWrongAnswers() {
        return previous_wrongAnswers;
    }

    /**
     * Sets the previous number of wrong answers given by the player.
     *
     * @param wrongAnswers The number of wrong answers.
     */
    public void setPreviousWrongAnswers(int wrongAnswers) {
        this.previous_wrongAnswers = wrongAnswers;
    }
}
