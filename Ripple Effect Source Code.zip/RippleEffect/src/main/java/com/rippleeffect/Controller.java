/*
Classname: Controller.java
Author: Win Sy, Leigh Tabanao, Timothy Tiu
Date: July 25, 2023
Description: The Controller in charge of all functions for the Application.
*/

package com.rippleeffect;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Region;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The Controller class is responsible for managing the user interface and user interactions in the Ripple Effect game.
 * It handles game logic, loading and saving game data, and displaying game statistics and achievements.
 */
public class Controller {
    private static final String PREVIOUS_SCORE_FILE_PATH = "src/main/assets/previous_score.txt";
    private final List<String> factsList = new ArrayList<>();
    private final List<ArrayList<String>> questionsChoicesList = new ArrayList<>();
    private final List<String> questionsList = new ArrayList<>();
    private final List<String> answersList = new ArrayList<>();
    private final AtomicBoolean cancelButtonClicked = new AtomicBoolean(false);
    private final List<Achievement> achievementsList = new ArrayList<>();
    private PreviousData previousData;
    private int score;
    private int correctAnswers;
    private int wrongAnswers;
    private int current_score;
    private int current_correctAnswers;
    private int current_wrongAnswers;
    private int previous_score;
    private int previous_correctAnswers;
    private int previous_wrongAnswers;

    @FXML
    private TextArea didyouknow;

    @FXML
    private TextField nameLabel;

    /**
     * Initializes the Controller by loading data from files and displaying initial game statistics.
     */
    @FXML
    protected void initialize() {

        loadFactsFromFile();
        displayRandomFact();
        loadQuestionsFromFile();
        loadAnswersFromFile();
        loadAchievementsFromFile();

        // Load the game data from the file during initialization
        // Add a field to store the loaded game data
        GameData gameData = loadGameDataFromFile();

        // If there is saved game data, update the UI with the loaded statistics
        if (gameData != null) {
            nameLabel.setText(gameData.getName());
            score = gameData.getScore();
            correctAnswers = gameData.getCorrectAnswers();
            wrongAnswers = gameData.getWrongAnswers();
        }
        else {
            score = 0;
            correctAnswers = 0;
            wrongAnswers = 0;
        }

        // Load the previous data data during initialization
        previousData = loadPreviousDataFromFile();

        // If there is saved previous data, update the variables with the loaded statistics
        if (previousData != null) {
            previous_score = previousData.getPreviousScore();
            previous_correctAnswers = previousData.getPreviousCorrectAnswers();
            previous_wrongAnswers = previousData.getPreviousWrongAnswers();
        } else {
            // If no previous data is available, set variables to default values
            previous_score = 0;
            previous_correctAnswers = 0;
            previous_wrongAnswers = 0;
        }
    }

    /**
     * Starts the game and allows the user to answer quiz questions.
     * Displays questions in a custom dialog with choices (A, B, C, D).
     * Updates game statistics based on user's answers.
     */
    @FXML
    protected void startGameHandler() {
        if (!questionsList.isEmpty() && !questionsChoicesList.isEmpty()) {
            // Load the game data from the file during initialization
            // Add a field to store the loaded game data
            GameData gameData = loadGameDataFromFile();

            // Initialize previousData with the loaded data
            previousData = new PreviousData(previous_score, previous_correctAnswers, previous_wrongAnswers);

            // Assigns the Values to Zero so that there are no Garbage Values
            current_score = 0;
            current_wrongAnswers = 0;
            current_correctAnswers = 0;
            cancelButtonClicked.set(false);

            // If there is saved game data, update the UI with the loaded statistics
            if (gameData != null) {
                nameLabel.setText(gameData.getName());
                score = gameData.getScore();
                correctAnswers = gameData.getCorrectAnswers();
                wrongAnswers = gameData.getWrongAnswers();
            }

            for (int i = 0; i < 10 && !cancelButtonClicked.get(); i++) { // Loop until 10 questions or "Cancel" clicked
                Random random = new Random();
                int randomIndex = random.nextInt(questionsList.size());
                String question = questionsList.get(randomIndex);
                ArrayList<String> choices = questionsChoicesList.get(randomIndex);
                String correctAnswer = answersList.get(randomIndex); // Get the correct answer from answersList

                Alert alert = new Alert(Alert.AlertType.NONE); // Use NONE to create a custom dialog
                alert.setTitle("Quiz Game");
                alert.setHeaderText(question);

                String choicesText = "A) " + choices.get(0) +
                        "\nB) " + choices.get(1) +
                        "\nC) " + choices.get(2) +
                        "\nD) " + choices.get(3);

                alert.setContentText(choicesText);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);

                // Create custom buttons for choices A, B, C, and D
                ButtonType buttonTypeA = new ButtonType("A");
                ButtonType buttonTypeB = new ButtonType("B");
                ButtonType buttonTypeC = new ButtonType("C");
                ButtonType buttonTypeD = new ButtonType("D");

                // Add the buttons to the dialog, including the Cancel button
                alert.getButtonTypes().setAll(buttonTypeA, buttonTypeB, buttonTypeC, buttonTypeD, ButtonType.CANCEL);

                Optional<ButtonType> result = alert.showAndWait();
                result.ifPresent(buttonType -> {
                    if (buttonType == buttonTypeA || buttonType == buttonTypeB ||
                            buttonType == buttonTypeC || buttonType == buttonTypeD) {
                        // Handle the selectedChoice and display the result accordingly.
                        String selectedChoice = buttonType.getText();
                        if (selectedChoice.equalsIgnoreCase(correctAnswer)) {
                            // User answered correctly
                            current_score++; // Increment the score for correct answer
                            current_correctAnswers++; // Increment the number of correct answers
                            Alert correctAlert = new Alert(Alert.AlertType.INFORMATION);
                            correctAlert.setTitle("Correct!");
                            correctAlert.setHeaderText(null);
                            correctAlert.setContentText("Congratulations! That's the correct answer.");
                            correctAlert.showAndWait();
                        } else {
                            // User answered incorrectly
                            current_score--;
                            current_wrongAnswers++; // Increment the number of wrong answers
                            Alert wrongAlert = new Alert(Alert.AlertType.INFORMATION);
                            wrongAlert.setTitle("Wrong!");
                            wrongAlert.setHeaderText(null);
                            wrongAlert.setContentText("Oops! That's the wrong answer.");
                            wrongAlert.showAndWait();
                        }
                    } else if (buttonType == ButtonType.CANCEL) {
                        cancelButtonClicked.set(true); // Set the flag if "Cancel" button is clicked
                    }
                });
            }

            // Show the final score and the number of correct and wrong answers after the game ends
            Alert scoreAlert = new Alert(Alert.AlertType.INFORMATION);
            scoreAlert.setTitle("Game Over!");
            scoreAlert.setHeaderText(null);

            String improvementMsg = "";
            String regressionMsg = "";

            // Compare the current scores with the previous values
            int scoreImprovement = current_score - previous_score; // Compute the score improvement
            if (scoreImprovement > 0) {
                improvementMsg = "\nScore Improvement: +" + scoreImprovement + " points";
            } else if (scoreImprovement < 0) {
                regressionMsg = "\nScore Regression: " + scoreImprovement + " points";
            }

            int correctAnswersImprovement = current_correctAnswers - previous_correctAnswers; // Compute the correct answers improvement
            if (correctAnswersImprovement > 0) {
                improvementMsg += "\nCorrect Answers Improvement: +" + correctAnswersImprovement;
            } else if (correctAnswersImprovement < 0) {
                regressionMsg += "\nCorrect Answers Regression: " + correctAnswersImprovement;
            }

            int wrongAnswersImprovement = current_wrongAnswers - previous_wrongAnswers; // Compute the wrong answers improvement
            if (wrongAnswersImprovement < 0) {
                improvementMsg += "\nWrong Answers Improvement: " + wrongAnswersImprovement;
            } else if (wrongAnswersImprovement > 0) {
                regressionMsg += "\nWrong Answers Regression: +" + wrongAnswersImprovement;
            }

            String scoreText = "Your final score: " + current_score +
                    "\nCorrect Answers: " + current_correctAnswers +
                    "\nWrong Answers: " + current_wrongAnswers;

            String improvementText = improvementMsg.isEmpty() ? "" : "\n\nImprovements:" + improvementMsg;
            String regressionText = regressionMsg.isEmpty() ? "" : "\n\nRegressions:" + regressionMsg;

            scoreAlert.setContentText(scoreText + improvementText + regressionText);
            scoreAlert.showAndWait();

            // Add the previous score, correctAnswers, and wrongAnswers to the loaded game data (if available)
            if (gameData != null) {
                score += current_score;
                correctAnswers += current_correctAnswers;
                wrongAnswers += current_wrongAnswers;
            }

            // Create a GameData object to save the updated game data
            GameData updatedGameData = new GameData(nameLabel.getText(), score, correctAnswers, wrongAnswers);

            // Save the updated game data to the "gameData.txt" file in CSV format
            saveGameDataToTextFile(updatedGameData);

            // Assign the current session's data to the previousData object
            previousData.setPreviousScore(current_score);
            previousData.setPreviousCorrectAnswers(current_correctAnswers);
            previousData.setPreviousWrongAnswers(current_wrongAnswers);

            // Save the current session's data as the previous session's data
            savePreviousDataToFile();
        }
    }

    /**
     * Compares the user's current game statistics with the previous game statistics.
     * Displays a dialog with the comparison results.
     */
    @FXML
    protected void compareScoresHandler() {
        // Check if current_score, current_correctAnswers, and current_wrongAnswers have valid values
        if (current_score == 0 && current_correctAnswers == 0 && current_wrongAnswers == 0) {
            // Display an error dialog if the current scores are not available
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Error");
            errorAlert.setHeaderText(null);
            errorAlert.setContentText("Play a game first to compare with previous scores.");
            errorAlert.showAndWait();
            return;
        }

        // The rest of the code to display the comparison dialog
        Alert comparisonAlert = new Alert(Alert.AlertType.INFORMATION);
        comparisonAlert.setTitle("Score Comparison");
        comparisonAlert.setHeaderText(null);
        String scoreComparisonText = "";

        scoreComparisonText += "Your current score: " + current_score +
                "\nCorrect Answers: " + current_correctAnswers +
                "\nWrong Answers: " + current_wrongAnswers + "\n";

        scoreComparisonText += "\nYour previous score: " + previous_score +
                "\nCorrect Answers: " + previous_correctAnswers +
                "\nWrong Answers: " + previous_wrongAnswers + "\n";

        // Compare the current scores with the previous values
        int scoreImprovement = current_score - previous_score; // Compute the score improvement

        if (scoreImprovement > 0) {
            scoreComparisonText += "\nYour score improved by " + scoreImprovement + " points!\n";
        } else if (scoreImprovement < 0) {
            scoreComparisonText += "\nYour score decreased by " + (-scoreImprovement) + " points.\n";
        } else {
            scoreComparisonText += "\nYour score remains the same as the previous game.\n";
        }

        int correctAnswersImprovement = current_correctAnswers - previous_correctAnswers; // Compute the correct answers improvement
        if (correctAnswersImprovement > 0) {
            scoreComparisonText += "You answered " + correctAnswersImprovement + " more questions correctly!\n";
        } else if (correctAnswersImprovement < 0) {
            scoreComparisonText += "You answered " + (-correctAnswersImprovement) + " fewer questions correctly.\n";
        } else {
            scoreComparisonText += "The number of correct answers remains the same.\n";
        }

        int wrongAnswersImprovement = current_wrongAnswers - previous_wrongAnswers; // Compute the wrong answers improvement
        if (wrongAnswersImprovement > 0) {
            scoreComparisonText += "You answered " + wrongAnswersImprovement + " fewer questions incorrectly!\n";
        } else if (wrongAnswersImprovement < 0) {
            scoreComparisonText += "You answered " + (-wrongAnswersImprovement) + " more questions incorrectly.\n";
        } else {
            scoreComparisonText += "The number of wrong answers remains the same.\n";
        }

        comparisonAlert.setContentText(scoreComparisonText);
        comparisonAlert.showAndWait();
    }

    /**
     * Allows the user to change their name.
     * Displays an input dialog to get the new name from the user.
     * Updates the UI with the new name and shows a greeting with the new name.
     */
    @FXML
    protected void changeNameHandler() {
        // Use an input dialog to get the new name from the user
        TextInputDialog dialog = new TextInputDialog(nameLabel.getText());
        dialog.setTitle("Change Name");
        dialog.setHeaderText(null);
        dialog.setContentText("Enter your name:");

        // Get the response from the user
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(name -> {
            // Set the nameLabel text to the new name
            nameLabel.setText(name);

            // You can now use the new name for any other logic you need
            // For example, you can display a greeting with the new name.
            Alert greetingAlert = new Alert(Alert.AlertType.INFORMATION);
            greetingAlert.setTitle("Hello, " + name + "!");
            greetingAlert.setHeaderText(null);
            greetingAlert.setContentText("Let's play the quiz game!");
            greetingAlert.showAndWait();
        });
    }

    /**
     * Displays game statistics and unlocked achievements in a custom dialog.
     * If no game data is available, an alert indicating that no data is available is shown.
     */
    @FXML
    protected void statsHandler() {
        // Load the game data from the file
        GameData gameData = loadGameDataFromFile();

        if (gameData != null) {
            // Create a custom dialog to show the statistics and all achievements
            Alert statsAlert = new Alert(Alert.AlertType.INFORMATION);
            statsAlert.setTitle("Game Statistics and Achievements");
            statsAlert.setHeaderText(null);

            String statsText = String.format("Name: %s\nScore: %d\nCorrect Answers: %d\nWrong Answers: %d",
                    gameData.getName(), gameData.getScore(), gameData.getCorrectAnswers(), gameData.getWrongAnswers());

            // Check for unlocked and locked achievements based on the player's score
            StringBuilder achievementsText = new StringBuilder("\n\nAchievements:\n");
            for (Achievement achievement : achievementsList) {
                String achievementLine = String.format("%s (%d points)", achievement.name(), achievement.points());
                if (gameData.getScore() >= achievement.points()) {
                    // If the achievement is unlocked
                    achievementLine += " - Unlocked";
                } else {
                    // If the achievement is not unlocked
                    achievementLine += " - Locked";
                }
                achievementsText.append(achievementLine).append("\n");
            }

            statsAlert.setContentText(statsText + achievementsText);
            statsAlert.showAndWait();
        } else {
            // If no game data is available, show an alert indicating that no data is available.
            Alert noDataAlert = new Alert(Alert.AlertType.INFORMATION);
            noDataAlert.setTitle("Game Statistics and Achievements");
            noDataAlert.setHeaderText(null);
            noDataAlert.setContentText("No game data available. Start playing the game to generate statistics.");
            noDataAlert.showAndWait();
        }
    }

    /**
     * Resets all statistics and saves the reset game data to the "gameData.txt" file in CSV format.
     * Also, resets the previous score and saves it to the PREVIOUS_SCORE_FILE_PATH in CSV format.
     * Finally, displays a confirmation dialog to inform the user that stats have been reset.
     */
    @FXML
    protected void resetStatsHandler() {
        // Reset all the stats to 0
        score = 0;
        correctAnswers = 0;
        wrongAnswers = 0;
        current_score = 0;
        current_correctAnswers = 0;
        current_wrongAnswers = 0;

        // Save the reset game data to the "gameData.txt" file in CSV format
        GameData gameData = new GameData(nameLabel.getText(), score, correctAnswers, wrongAnswers);
        saveGameDataToTextFile(gameData);

        // Reset the previous score to 0 and save it to the PREVIOUS_SCORE_FILE_PATH in CSV format
        int previous_score = 0;
        int previous_correctAnswers = 0;
        int previous_wrongAnswers = 0;
        String csvData = String.format("%d,%d,%d", previous_score, previous_correctAnswers, previous_wrongAnswers);
        try {
            FileWriter fileWriter = new FileWriter(PREVIOUS_SCORE_FILE_PATH);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(csvData);
            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Update the class-level variables with the reset values
        this.previous_score = previous_score;
        this.previous_correctAnswers = previous_correctAnswers;
        this.previous_wrongAnswers = previous_wrongAnswers;

        // Show a confirmation dialog to inform the user that stats have been reset
        Alert confirmationAlert = new Alert(Alert.AlertType.INFORMATION);
        confirmationAlert.setTitle("Stats Reset");
        confirmationAlert.setHeaderText(null);
        confirmationAlert.setContentText("All statistics have been reset to zero.");
        confirmationAlert.showAndWait();
    }

    /**
     * Quits the game by closing the application.
     */
    @FXML
    protected void quitGameHandler() {
        Platform.exit();
    }

    /**
     * Loads achievements from the "achievements.txt" file and populates the achievementsList.
     * Each line in the file represents an achievement in CSV format: "name,points".
     * The method reads the file, parses each line, and creates an Achievement object with the name and points.
     * The created Achievement objects are added to the achievementsList.
     */
    private void loadAchievementsFromFile() {
        try {
            InputStream inputStream = new FileInputStream("src/main/assets/achievements.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 2) {
                    String name = data[0].trim();
                    int points = Integer.parseInt(data[1].trim());
                    Achievement achievement = new Achievement(name, points);
                    achievementsList.add(achievement);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads facts from the "facts.txt" file and populates the factsList.
     * Each line in the file represents a fact.
     * The method reads the file and adds each fact to the factsList.
     */
    private void loadFactsFromFile() {
        try {
            InputStream inputStream = new FileInputStream("src/main/assets/facts.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                factsList.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads questions and choices from the "questions.txt" file and populates the questionsList and questionsChoicesList.
     * Each question in the file has four lines: question, choice A, choice B, and choice C.
     * The method reads the file, adds the question to the questionsList, and creates a list of choices for each question.
     * The choices are added to the questionsChoicesList.
     */
    private void loadQuestionsFromFile() {
        try {
            InputStream inputStream = new FileInputStream("src/main/assets/questions.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                questionsList.add(line);
                ArrayList<String> choices = new ArrayList<>();
                choices.add(reader.readLine());
                choices.add(reader.readLine());
                choices.add(reader.readLine());
                choices.add(reader.readLine());
                questionsChoicesList.add(choices);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads answers from the "answers.txt" file and populates the answersList.
     * Each line in the file represents an answer to a question.
     * The method reads the file and adds each answer to the answersList.
     */
    private void loadAnswersFromFile() {
        try {
            InputStream inputStream = new FileInputStream("src/main/assets/answers.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                answersList.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads game data from the "gameData.txt" file and returns a GameData object containing the loaded data.
     * The "gameData.txt" file should be in CSV format: "name,score,correctAnswers,wrongAnswers".
     * The method reads the file, parses the data, and creates a GameData object with the name, score, correctAnswers, and wrongAnswers.
     * If the file is empty or not found, it returns null.
     *
     * @return A GameData object containing the loaded data or null if no data is available.
     */
    private GameData loadGameDataFromFile() {
        GameData loadedGameData = null;
        try {
            FileReader fileReader = new FileReader("src/main/assets/gameData.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line = bufferedReader.readLine();
            if (line != null) {
                String[] data = line.split(",");
                String name = data[0];
                int score = Integer.parseInt(data[1]);
                int correctAnswers = Integer.parseInt(data[2]);
                int wrongAnswers = Integer.parseInt(data[3]);

                loadedGameData = new GameData(name, score, correctAnswers, wrongAnswers);
            }

            bufferedReader.close();
            fileReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return loadedGameData;
    }

    /**
     * Saves the given GameData to the "gameData.txt" file in CSV format.
     * The method converts the GameData object to CSV format and writes it to the file.
     *
     * @param gameData The GameData object to be saved to the file.
     */
    private static void saveGameDataToTextFile(GameData gameData) {
        try {
            String filePath = "src/main/assets/gameData.txt";
            FileWriter fileWriter = new FileWriter(filePath);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Convert the game data to CSV format and write it to the file
            String csvData = String.format("%s,%d,%d,%d",
                    gameData.getName(), gameData.getScore(), gameData.getCorrectAnswers(), gameData.getWrongAnswers());

            bufferedWriter.write(csvData);

            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Displays a random fact from the factsList in the didyouknow label.
     * If the factsList is empty, "No facts found." will be displayed.
     */
    private void displayRandomFact() {
        if (!factsList.isEmpty()) {
            Random random = new Random();
            int randomIndex = random.nextInt(factsList.size());
            String randomFact = factsList.get(randomIndex);
            didyouknow.setText(randomFact);
        } else {
            didyouknow.setText("No facts found.");
        }
    }

    /**
     * Loads the previous session's data from the "previous_score.txt" file and returns a PreviousData object containing the loaded data.
     * The "previous_score.txt" file should be in CSV format: "previous_score,previous_correctAnswers,previous_wrongAnswers".
     * The method reads the file, parses the data, and creates a PreviousData object with the previous scores.
     * If the file is empty or not found, it returns null.
     *
     * @return A PreviousData object containing the loaded data or null if no data is available.
     */
    private PreviousData loadPreviousDataFromFile() {
        try {
            FileReader fileReader = new FileReader(PREVIOUS_SCORE_FILE_PATH);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line = bufferedReader.readLine();
            if (line != null) {
                String[] data = line.split(",");
                int previous_score = Integer.parseInt(data[0]);
                int previous_correctAnswers = Integer.parseInt(data[1]);
                int previous_wrongAnswers = Integer.parseInt(data[2]);

                // Update the previousData with the loaded data
                previousData = new PreviousData(previous_score, previous_correctAnswers, previous_wrongAnswers);
            }
            bufferedReader.close();
            fileReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return previousData; // Return the loaded previousData object
    }

    /**
     * Saves the current session's data (previousData) to the PREVIOUS_SCORE_FILE_PATH in CSV format.
     * This method is called before starting a new game to save the previous session's data.
     */
    private void savePreviousDataToFile() {
        try {
            FileWriter fileWriter = new FileWriter(PREVIOUS_SCORE_FILE_PATH);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Convert the previousData to CSV format and write it to the file
            String csvData = String.format("%d,%d,%d",
                    previousData.getPreviousScore(), previousData.getPreviousCorrectAnswers(), previousData.getPreviousWrongAnswers());

            bufferedWriter.write(csvData);

            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Saves the current game data to the "gameData.txt" file in CSV format before exiting the application.
     * This method is called when the application is closed to store the current game data for future use.
     */
    void saveGameDataOnExit() {
        // Create a GameData object to save the game data
        GameData gameData = new GameData(nameLabel.getText(), score, correctAnswers, wrongAnswers);

        // Save the game data to the "gameData.txt" file in CSV format
        saveGameDataToTextFile(gameData);

        savePreviousDataToFile();
    }

    /**
     * A record representing an Achievement with its name and the points required to unlock it.
     * This record is used to store achievement information read from the achievements.txt file.
     */
    private record Achievement(String name, int points) {
    }
}