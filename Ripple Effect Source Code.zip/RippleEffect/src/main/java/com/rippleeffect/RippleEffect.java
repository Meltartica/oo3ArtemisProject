/*
Classname: RippleEffect.java
Author: Win Sy, Leigh Tabanao, Timothy Tiu
Date: July 24, 2023
Description: Main Program to Start the Application by showing the Menu from the FXML file
*/

package com.rippleeffect;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * The RippleEffect class is the main class of the Ripple Effect game application.
 * It extends the JavaFX Application class to create the graphical user interface and
 * manage the game's lifecycle.
 */
public class RippleEffect extends Application {
    private Controller controller; // Reference to the controller associated with the FXML file

    /**
     * The start method is called when the JavaFX application is launched.
     * It loads the FXML file containing the menu, sets up the application's scene,
     * and displays the program's window.
     *
     * @param stage The primary stage for this application, representing the window.
     * @throws IOException If there is an error loading the FXML file.
     */
    @Override
    public void start(Stage stage) throws IOException {
        // Load the FXML file containing the Menu
        FXMLLoader fxmlLoader = new FXMLLoader(RippleEffect.class.getResource("menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());

        // Set the Title and Display the Program
        stage.setTitle("Ripple Effect");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        // Get the reference to the Controller object associated with the FXML file
        controller = fxmlLoader.getController();
    }

    /**
     * The stop method is called when the application is shutting down.
     * It saves the game data using the correct Controller object, if available.
     *
     * @throws Exception If there is an error during the save process.
     */
    @Override
    public void stop() throws Exception {
        // Save the game data using the correct Controller object
        if (controller != null) {
            controller.saveGameDataOnExit();
        }

        super.stop();
    }

    /**
     * The main method is the entry point of the Ripple Effect application.
     * It launches the JavaFX application.
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        launch(args);
    }
}
